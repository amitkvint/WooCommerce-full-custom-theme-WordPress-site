wooShortcodeMeta={
	attributes:[
		{
			label:"Limit",
			id:"limit",
			help:"Number of posts to show (default: 5)."
		},
		{
			label:"Image",
			id:"image",
			help:"Thumbnail size, 0 = off (default: 0)."
		}
		],
		disablePreview:true,
		defaultContent:"",
		shortcode:"related_posts"
};