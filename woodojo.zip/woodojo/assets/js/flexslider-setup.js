jQuery( window ).load( function ( e ) {
	if ( jQuery( '.flexslider' ).length ) {
		jQuery( '.flexslider' ).flexslider();
	}
});